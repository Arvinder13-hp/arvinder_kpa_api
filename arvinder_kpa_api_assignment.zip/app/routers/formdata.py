from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import SessionLocal

router = APIRouter(prefix="/formdata", tags=["FormData"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/submit", response_model=schemas.FormDataResponse)
def submit_form(form: schemas.FormDataCreate, db: Session = Depends(get_db)):
    new_form = models.FormData(**form.dict())
    db.add(new_form)
    db.commit()
    db.refresh(new_form)
    return new_form

@router.get("/{id}", response_model=schemas.FormDataResponse)
def get_form(id: int, db: Session = Depends(get_db)):
    form = db.query(models.FormData).filter(models.FormData.id == id).first()
    if not form:
        raise HTTPException(status_code=404, detail="Form not found")
    return form
