from pydantic import BaseModel

class FormDataCreate(BaseModel):
    name: str
    email: str
    message: str

class FormDataResponse(FormDataCreate):
    id: int

    class Config:
        orm_mode = True
