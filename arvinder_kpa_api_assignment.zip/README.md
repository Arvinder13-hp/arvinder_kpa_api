# KPA API Assignment - Arvinder Kaur

## 🔧 Setup Instructions
1. Clone the repo or unzip
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Set up a PostgreSQL database named `kpa_db` and update the `.env` if needed.
4. Run the server:
   ```bash
   uvicorn app.main:app --reload
   ```

## 🚀 Tech Stack
- FastAPI
- PostgreSQL
- SQLAlchemy
- Pydantic

## 📌 Implemented APIs
1. `POST /formdata/submit` – Form submission with optional file upload.
2. `GET /formdata/{id}` – Fetch submitted form data.

## 🎬 Videos
- [Project Features Video](https://drive.com/arvinder_features.mp4)
- [Technical Explanation Video](https://drive.com/arvinder_technical.mp4)
